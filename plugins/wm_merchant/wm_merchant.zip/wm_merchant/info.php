<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

$info = array(
	'name' => 'WebMoney Merchant',
	'description' => 'Автоматический прием WM-платежей',
	'version' => '1.2',
	'author' => 'Руслан',
	'plugin_url' => 'http://rgblog.ru/',
	'author_url' => 'http://rgblog.ru/',
	'group' => 'template'
);

# end file